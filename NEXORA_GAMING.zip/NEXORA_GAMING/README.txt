NEXORA GAMING
=============
1. ZIP entpacken.
2. index.html im Browser öffnen.
3. In der Spielebibliothek ein Spiel auswählen.
4. In jedem Spiel führt HOMEPAGE zurück zur Hauptseite.

Enthalten:
- Space Shooter
- Neon Snake
- Neon Racing
- Block World (einfaches 2D-Bau-/Abbau-Spiel)
- Zombie Survival
- Jump & Run
- Tower Defense
- Duo Arena (lokaler 2-Spieler-Modus)

Hinweis: Das Multiplayer-Spiel ist lokal an einer Tastatur, kein Online-Multiplayer.
Die Spiele sind einfache eigenständige Browser-Minispiele. Highscores/Spielstände werden
nicht serverweit synchronisiert.
